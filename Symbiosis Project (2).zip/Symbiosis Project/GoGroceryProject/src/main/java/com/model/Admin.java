package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="admins")
public class Admin {

	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="admin_seq")
	@SequenceGenerator(name="admin_seq",sequenceName="admin_sequence")
	private long adminId;
	private String adminName;
	private long adminContactNo;
	private String adminEmail;
	private String passward;
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(long adminId, String adminName, long adminContactNo, String adminEmail, String passward) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminContactNo = adminContactNo;
		this.adminEmail = adminEmail;
		this.passward = passward;
	}
	public long getAdminId() {
		return adminId;
	}
	public void setAdminId(long adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public long getAdminContactNo() {
		return adminContactNo;
	}
	public void setAdminContactNo(long adminContactNo) {
		this.adminContactNo = adminContactNo;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", adminContactNo=" + adminContactNo
				+ ", adminEmail=" + adminEmail + ", passward=" + passward + "]";
	}

	
}
