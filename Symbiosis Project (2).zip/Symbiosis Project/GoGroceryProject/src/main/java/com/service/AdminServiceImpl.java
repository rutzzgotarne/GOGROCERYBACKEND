package com.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.AdminRepository;
import com.model.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRepository adminRepo;


	@Override
	public Admin addAdmin(Admin ad)
	{
	Admin a = new Admin();
	a = adminRepo.save(ad);
	//sendRegistrationMail(a.getAdminId());
	return a;
	}

	@Override
	public Admin getAdminById(long id)
	{
	return adminRepo.findById(id).orElse(null);
	}

	@Override
	public List<Admin> getAllAdmin()
	{
	return adminRepo.findAll();
	}
	
	@Override
	public Admin updateAdmin(Admin admin)
	{
	Admin existingAdmin = adminRepo.findById(admin.getAdminId()).orElse(null);
	existingAdmin.setAdminName(admin.getAdminName());

	Admin updatedAdmin = adminRepo.save(existingAdmin);
	return updatedAdmin;
	}

	@Override
	public Map<String, Object> deleteAdmin(long id)
	{
	Map<String, Object> response = new HashMap<>();
	Admin a = adminRepo.findById(id).orElse(null);

	if(a == null)
	{
	response.put("Not Deleted", "Admin Not Deleted Because ID not FOUND");
	}
	else
	{
	adminRepo.delete(a);
	response.put("Deleted", "Admin Deleted Successfully");
	}
	return response;
	}


}
