package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="suppliers")
public class Supplier {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="customer_seq")
	@SequenceGenerator(name="customer_seq",sequenceName="customer_sequence")
	private long supplierId;
	private String supplierName;
	private String supplierAddress;
	private long supplierContactNo;
	public Supplier() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Supplier(long supplierId, String supplierName, String supplierAddress, long supplierContactNo) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierAddress = supplierAddress;
		this.supplierContactNo = supplierContactNo;
	}
	public long getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	public long getSupplierContactNo() {
		return supplierContactNo;
	}
	public void setSupplierContactNo(long supplierContactNo) {
		this.supplierContactNo = supplierContactNo;
	}
	
	
}
