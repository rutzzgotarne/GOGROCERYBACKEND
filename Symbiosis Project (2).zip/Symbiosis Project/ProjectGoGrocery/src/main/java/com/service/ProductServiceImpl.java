package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.ProductRepository;
import com.model.Product;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product getProductById(int productId) {
        Optional<Product> product = productRepository.findById(productId);
        return product.orElse(null);
    }

    @Override
    public Product updateProduct(Product product, int productId) {
        Optional<Product> existingProduct = productRepository.findById(productId);
        if (existingProduct.isPresent()) {
            Product updatedProduct = existingProduct.get();
            updatedProduct.setProductCategory(product.getProductCategory());
            updatedProduct.setProductName(product.getProductName());
            updatedProduct.setProductPrice(product.getProductPrice());
            updatedProduct.setDescription(product.getDescription());
            updatedProduct.setImageData(product.getImageData());
            updatedProduct.setProductQuantity(product.getProductQuantity());
            updatedProduct.setOrder(product.getOrder());
            return productRepository.save(updatedProduct);
        }
        return null;
    }

    @Override
    public void deleteProduct(int productId) {
        productRepository.deleteById(productId);
    }
}

