package com.service;

import java.util.List;
import com.model.Order;

public interface OrderService {
    Order saveOrder(Order order);
    List<Order> getAllOrders();
    Order getOrderById(long orderId);
    Order updateOrder(Order order, long orderId);
    void deleteOrder(long orderId);
}

