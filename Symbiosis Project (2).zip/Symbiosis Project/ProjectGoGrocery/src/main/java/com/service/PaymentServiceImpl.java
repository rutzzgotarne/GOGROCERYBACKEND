package com.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.PaymentRepository;
import com.model.Payment;


@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public Payment getPaymentById(long paymentId) {
        Optional<Payment> payment = paymentRepository.findById(paymentId);
        return payment.orElse(null);
    }

    @Override
    public Payment updatePayment(Payment payment, long paymentId) {
        Optional<Payment> existingPayment = paymentRepository.findById(paymentId);
        if (existingPayment.isPresent()) {
            Payment updatedPayment = existingPayment.get();
            updatedPayment.setAmount(payment.getAmount());
            updatedPayment.setCurrency(payment.getCurrency());
            updatedPayment.setPaymentType(payment.getPaymentType());
            updatedPayment.setPaymentStatus(payment.getPaymentStatus());
            updatedPayment.setPaymentDate(payment.getPaymentDate());
            updatedPayment.setOrder(payment.getOrder());
            return paymentRepository.save(updatedPayment);
        }
        return null;
    }

    @Override
    public void deletePayment(long paymentId) {
        paymentRepository.deleteById(paymentId);
    }
}
