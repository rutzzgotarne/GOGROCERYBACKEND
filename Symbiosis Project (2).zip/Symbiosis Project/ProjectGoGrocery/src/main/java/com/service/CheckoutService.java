package com.service;

import java.util.List;
import com.model.Checkout;

public interface CheckoutService {
    Checkout saveCheckout(Checkout checkout);
    List<Checkout> getAllCheckouts();
    Checkout getCheckoutById(Long id);
    Checkout updateCheckout(Checkout checkout, Long id);
    void deleteCheckout(Long id);
}
