package com.service;

import java.util.List;
import com.model.Cart;

public interface CartService {
    Cart saveCart(Cart cart);
    List<Cart> getAllCarts();
    Cart getCartById(Long id);
    Cart updateCart(Cart cart, Long id);
    void deleteCart(Long id);
}
