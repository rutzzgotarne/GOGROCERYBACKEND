package com.service;

import java.util.List;
import com.model.Supplier;

public interface SupplierService {
    Supplier saveSupplier(Supplier supplier);
    List<Supplier> getAllSuppliers();
    Supplier getSupplierById(long supplierId);
    Supplier updateSupplier(Supplier supplier, long supplierId);
    void deleteSupplier(long supplierId);
}
