package com.service;

import java.util.List;
import com.model.Payment;

public interface PaymentService {
    Payment savePayment(Payment payment);
    List<Payment> getAllPayments();
    Payment getPaymentById(long paymentId);
    Payment updatePayment(Payment payment, long paymentId);
    void deletePayment(long paymentId);
}

