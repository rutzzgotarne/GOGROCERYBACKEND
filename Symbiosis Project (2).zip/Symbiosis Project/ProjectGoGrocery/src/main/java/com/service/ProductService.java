package com.service;

import java.util.List;
import com.model.Product;

public interface ProductService {
    Product saveProduct(Product product);
    List<Product> getAllProducts();
    Product getProductById(int productId);
    Product updateProduct(Product product, int productId);
    void deleteProduct(int productId);
}
