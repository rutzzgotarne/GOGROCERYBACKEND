package com.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.SupplierRepository;
import com.model.Supplier;

@Service
public class SupplierServiceImpl implements SupplierService {

    @Autowired
    private SupplierRepository supplierRepository;

    @Override
    public Supplier saveSupplier(Supplier supplier) {
        return supplierRepository.save(supplier);
    }

    @Override
    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    @Override
    public Supplier getSupplierById(long supplierId) {
        Optional<Supplier> supplier = supplierRepository.findById(supplierId);
        return supplier.orElse(null);
    }

    @Override
    public Supplier updateSupplier(Supplier supplier, long supplierId) {
        Optional<Supplier> existingSupplier = supplierRepository.findById(supplierId);
        if (existingSupplier.isPresent()) {
            Supplier updatedSupplier = existingSupplier.get();
            updatedSupplier.setSupplierName(supplier.getSupplierName());
            updatedSupplier.setSupplierAddress(supplier.getSupplierAddress());
            updatedSupplier.setSupplierContactNo(supplier.getSupplierContactNo());
            return supplierRepository.save(updatedSupplier);
        }
        return null;
    }

    @Override
    public void deleteSupplier(long supplierId) {
        supplierRepository.deleteById(supplierId);
    }
}
