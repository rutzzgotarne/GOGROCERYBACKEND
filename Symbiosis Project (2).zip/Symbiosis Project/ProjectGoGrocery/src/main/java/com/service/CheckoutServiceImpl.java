package com.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.CheckoutRepository;
import com.model.Checkout;
@Service
public class CheckoutServiceImpl implements CheckoutService {

    @Autowired
    private CheckoutRepository checkoutRepository;

    @Override
    public Checkout saveCheckout(Checkout checkout) {
        return checkoutRepository.save(checkout);
    }

    @Override
    public List<Checkout> getAllCheckouts() {
        return checkoutRepository.findAll();
    }

    @Override
    public Checkout getCheckoutById(Long id) {
        Optional<Checkout> checkout = checkoutRepository.findById(id);
        return checkout.orElse(null);
    }

    @Override
    public Checkout updateCheckout(Checkout checkout, Long id) {
        Optional<Checkout> existingCheckout = checkoutRepository.findById(id);
        if (existingCheckout.isPresent()) {
            Checkout updatedCheckout = existingCheckout.get();
            updatedCheckout.setCustomer(checkout.getCustomer());
            updatedCheckout.setCart(checkout.getCart());
            updatedCheckout.setTotalAmount(checkout.getTotalAmount());
            updatedCheckout.setPaymentMethod(checkout.getPaymentMethod());
            updatedCheckout.setShippingAddress(checkout.getShippingAddress());
            updatedCheckout.setOrderStatus(checkout.getOrderStatus());
            updatedCheckout.setCreatedAt(checkout.getCreatedAt());
            return checkoutRepository.save(updatedCheckout);
        }
        return null;
    }

    @Override
    public void deleteCheckout(Long id) {
        checkoutRepository.deleteById(id);
    }
}
