package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.model.Checkout;
import com.service.CheckoutService;
import java.util.List;

@RestController
@RequestMapping("/api/checkouts")
public class CheckoutController {

    @Autowired
    private CheckoutService checkoutService;

    @PostMapping("/save")
    public ResponseEntity<Checkout> createCheckout(@RequestBody Checkout checkout) {
        Checkout savedCheckout = checkoutService.saveCheckout(checkout);
        return ResponseEntity.ok(savedCheckout);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Checkout>> getAllCheckouts() {
        List<Checkout> checkouts = checkoutService.getAllCheckouts();
        return ResponseEntity.ok(checkouts);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<Checkout> getCheckoutById(@PathVariable("id") Long id) {
        Checkout checkout = checkoutService.getCheckoutById(id);
        if (checkout != null) {
            return ResponseEntity.ok(checkout);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Checkout> updateCheckout(@PathVariable("id") Long id, @RequestBody Checkout checkout) {
        Checkout updatedCheckout = checkoutService.updateCheckout(checkout, id);
        if (updatedCheckout != null) {
            return ResponseEntity.ok(updatedCheckout);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteCheckout(@PathVariable("id") Long id) {
        checkoutService.deleteCheckout(id);
        return ResponseEntity.noContent().build();
    }
}
