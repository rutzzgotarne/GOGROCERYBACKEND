package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.model.Product;
import com.service.ProductService;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/save")
    public ResponseEntity<Product> createProduct(@RequestParam("productCategory") String productCategory,
         @RequestParam("productName") String productName,
         @RequestParam("productPrice") int productPrice,
         @RequestParam("description") String description,
         @RequestParam("imageData") MultipartFile imageData,
         @RequestParam("productQuantity") int productQuantity) {
    	
    	try {
            Product product = new Product();
            product.setProductCategory(productCategory);
            product.setProductName(productName);
            product.setProductPrice(productPrice);
            product.setDescription(description);
            product.setImageData(imageData.getBytes());
            product.setProductQuantity(productQuantity);
            Product savedProduct = productService.saveProduct(product);
            return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/getAll")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") int productId) {
        Product product = productService.getProductById(productId);
        if (product != null) {
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable("id") int productId, @RequestParam("productCategory") String productCategory,
            @RequestParam("productName") String productName,
            @RequestParam("productPrice") int productPrice,
            @RequestParam("description") String description,
            @RequestParam("imageData") MultipartFile imageData,
            @RequestParam("productQuantity") int productQuantity) {
    	try {
            Product product = new Product();
            product.setProductCategory(productCategory);
            product.setProductName(productName);
            product.setProductPrice(productPrice);
            product.setDescription(description);
            product.setImageData(imageData.getBytes());
            product.setProductQuantity(productQuantity);
            Product savedProduct = productService.saveProduct(product);
            return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("id") int productId) {
        productService.deleteProduct(productId);
        return ResponseEntity.noContent().build();
    }
}

