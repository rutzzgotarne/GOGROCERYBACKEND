package com.grocery_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectGoGroceryApplicationTests {

	@Test
	void contextLoads() {
	}

}
